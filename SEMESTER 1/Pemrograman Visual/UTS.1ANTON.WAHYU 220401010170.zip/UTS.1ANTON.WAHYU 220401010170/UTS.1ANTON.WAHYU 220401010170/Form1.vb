﻿Public Class Form1
    Dim makanan As Integer
    Dim minuman As Integer
    Dim total As Integer
    Dim pembayaran As Integer
    Dim kembalian As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim makanan As Integer
        Dim minuman As Integer
        Dim total As Integer
        Dim pembayaran As Integer
        Dim kembalian As Integer
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            TextBox1.Text = 30000
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            TextBox1.Text = 25000
        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked = True Then
            TextBox1.Text = 20000
        End If
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        If RadioButton4.Checked = True Then
            TextBox2.Text = 10000
        End If
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton5.CheckedChanged
        If RadioButton5.Checked = True Then
            TextBox2.Text = 12000
        End If
    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton6.CheckedChanged
        If RadioButton6.Checked = True Then
            TextBox2.Text = 20000
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox1.Text = "Rp"
        TextBox2.Text = "Rp"
        TextBox3.Text = "Rp"
        TextBox4.Text = "Rp"
        TextBox5.Text = "Rp"
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        RadioButton4.Checked = False
        RadioButton5.Checked = False
        RadioButton6.Checked = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox3.Text = "" Then
            MsgBox("INPUTAN PEMBAYARAN BELUM DI ISI")
        Else
            pembayaran = TextBox4.Text
            total = TextBox3.Text
            kembalian = pembayaran - total
            TextBox5.Text = "Rp" & kembalian
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If TextBox1.Text = "" Then
            TextBox2.Text = ""
            MsgBox("SILAKAN UNTUK MEMILIH MENU MAKAN")
        Else
            makanan = TextBox1.Text
            total = makanan
            TextBox3.Text = total
            TextBox2.Text = "TIDAK DI BELI MINUMAN"
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If TextBox2.Text = "" Then
            TextBox1.Text = ""
            MsgBox("SILAKAN UNTUK MEMILIH MENU MINUMAN")
        Else
            minuman = TextBox2.Text
            total = minuman
            TextBox3.Text = total
            TextBox1.Text = "TIDAK DI BELI MAKANAN"
        End If
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            TextBox2.Text = ""
            MsgBox("SILAKAN UNTUK MEMILIH MENU MAKAN DAN MINUMAN")
        Else
            makanan = TextBox1.Text
            minuman = TextBox2.Text
            total = makanan + minuman
            TextBox3.Text = total
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        RadioButton4.Checked = False
        RadioButton5.Checked = False
        RadioButton6.Checked = False
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Me.Close()
    End Sub
End Class
